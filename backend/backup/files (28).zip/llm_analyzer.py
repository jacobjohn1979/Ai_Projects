"""
llm_analyzer.py — LLM-based document understanding via Claude API
Uses Claude to reason about document content and cross-document inconsistencies.

Capabilities:
  1. Single document analysis — find internal inconsistencies in OCR text
  2. Cross-document analysis — compare salary on payslip vs bank deposits
  3. Narrative fraud reasoning — explain WHY something looks suspicious
  4. Structured extraction — pull key fields reliably from messy OCR
"""

import os
import json
import logging
import urllib.request
import urllib.error
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()
log = logging.getLogger("fraud_detect.llm")

CLAUDE_API_URL  = "https://api.anthropic.com/v1/messages"
CLAUDE_MODEL    = "claude-sonnet-4-20250514"
LLM_ENABLED     = os.getenv("LLM_ANALYSIS_ENABLED", "false").lower() == "true"
MAX_TEXT_CHARS  = 8000   # truncate very long OCR to stay within token budget


def _call_claude(system_prompt: str, user_message: str, max_tokens: int = 1000) -> dict:
    """Call Claude API and return parsed JSON response."""
    if not LLM_ENABLED:
        return {"skipped": True, "reason": "LLM_ANALYSIS_ENABLED=false in .env"}

    try:
        body = json.dumps({
            "model":      CLAUDE_MODEL,
            "max_tokens": max_tokens,
            "system":     system_prompt,
            "messages":   [{"role": "user", "content": user_message}],
        }).encode("utf-8")

        req = urllib.request.Request(
            CLAUDE_API_URL,
            data    = body,
            method  = "POST",
            headers = {
                "Content-Type":      "application/json",
                "anthropic-version": "2023-06-01",
            },
        )

        with urllib.request.urlopen(req, timeout=30) as resp:
            data    = json.loads(resp.read())
            content = data.get("content", [{}])[0].get("text", "")

            # strip markdown fences if present
            clean = content.strip()
            if clean.startswith("```"):
                clean = "\n".join(clean.split("\n")[1:])
            if clean.endswith("```"):
                clean = "\n".join(clean.split("\n")[:-1])

            return json.loads(clean.strip())

    except json.JSONDecodeError as e:
        log.warning(f"LLM response not valid JSON: {e}")
        return {"error": "invalid_json_response"}
    except urllib.error.HTTPError as e:
        log.error(f"Claude API HTTP error {e.code}: {e.read().decode()}")
        return {"error": f"api_http_{e.code}"}
    except Exception as e:
        log.error(f"Claude API call failed: {e}")
        return {"error": str(e)}


# ═══════════════════════════════════════════════════════════════════════════════
#  1. SINGLE DOCUMENT ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════

SINGLE_DOC_SYSTEM = """You are a senior bank fraud analyst reviewing OCR-extracted text from financial documents.
Your job is to identify internal inconsistencies, suspicious patterns, and potential fraud signals.

Always respond with valid JSON only — no prose, no markdown fences. Schema:
{
  "doc_type_detected": "bank_statement|payslip|tax_document|utility_bill|id_card|unknown",
  "key_fields": {
    "name": "string or null",
    "account_number": "string or null",
    "period": "string or null",
    "total_income": "number or null",
    "total_debits": "number or null",
    "closing_balance": "number or null",
    "employer": "string or null",
    "address": "string or null"
  },
  "inconsistencies": [
    "description of each inconsistency found"
  ],
  "fraud_signals": [
    "specific fraud indicator with brief explanation"
  ],
  "authenticity_assessment": "genuine|suspicious|likely_fraudulent",
  "confidence": "high|medium|low",
  "reasoning": "2-3 sentence explanation of your assessment",
  "risk_score_suggestion": 0-100
}"""


def analyze_single_document(ocr_text: str, doc_type_hint: str = "") -> tuple:
    """
    Use Claude to analyze a single document's OCR text for inconsistencies.
    Returns (info_dict, flags_list).
    """
    flags, info = [], {}

    if not ocr_text or len(ocr_text.strip()) < 50:
        return {"llm_skipped": "insufficient_text"}, []

    truncated = ocr_text[:MAX_TEXT_CHARS]
    hint      = f"Document type hint: {doc_type_hint}\n\n" if doc_type_hint else ""

    result = _call_claude(
        system_prompt = SINGLE_DOC_SYSTEM,
        user_message  = f"{hint}OCR Text:\n{truncated}",
        max_tokens    = 800,
    )

    if result.get("skipped") or result.get("error"):
        info["llm_status"] = result
        return info, []

    info["llm_doc_type"]          = result.get("doc_type_detected", "unknown")
    info["llm_key_fields"]        = result.get("key_fields", {})
    info["llm_inconsistencies"]   = result.get("inconsistencies", [])
    info["llm_fraud_signals"]     = result.get("fraud_signals", [])
    info["llm_assessment"]        = result.get("authenticity_assessment", "unknown")
    info["llm_confidence"]        = result.get("confidence", "low")
    info["llm_reasoning"]         = result.get("reasoning", "")
    info["llm_risk_score"]        = result.get("risk_score_suggestion", 0)

    assessment = result.get("authenticity_assessment", "")
    confidence = result.get("confidence", "low")

    if assessment == "likely_fraudulent":
        flags.append("llm_assessed_likely_fraudulent")
        if confidence == "high":
            flags.append("llm_high_confidence_fraud")
    elif assessment == "suspicious":
        flags.append("llm_assessed_suspicious")

    for signal in result.get("fraud_signals", []):
        flags.append("llm_signal:" + signal[:60].lower().replace(" ", "_").replace(",", ""))

    inconsistencies = result.get("inconsistencies", [])
    if len(inconsistencies) >= 3:
        flags.append("llm_multiple_inconsistencies")
    elif inconsistencies:
        flags.append("llm_inconsistencies_detected")

    return info, flags


# ═══════════════════════════════════════════════════════════════════════════════
#  2. CROSS-DOCUMENT ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════

CROSS_DOC_SYSTEM = """You are a senior bank fraud analyst. You will receive OCR text from multiple financial documents submitted by the same loan applicant.

Cross-reference the documents and identify inconsistencies BETWEEN them — salary stated on payslip vs salary deposits visible in bank statement, address on utility bill vs address on bank statement, employer name consistency, date overlaps, etc.

Respond with valid JSON only. Schema:
{
  "cross_document_issues": [
    {
      "issue_type": "salary_mismatch|address_mismatch|employer_mismatch|date_gap|income_inflation|other",
      "severity": "high|medium|low",
      "doc_a": "which document",
      "doc_b": "which document",
      "description": "specific description of the inconsistency",
      "doc_a_value": "what doc A says",
      "doc_b_value": "what doc B says"
    }
  ],
  "overall_consistency": "consistent|minor_issues|major_inconsistencies",
  "applicant_profile": {
    "likely_monthly_income": "number or null",
    "income_confidence": "high|medium|low",
    "address": "string or null",
    "employer": "string or null"
  },
  "fraud_assessment": "genuine|suspicious|likely_fraudulent",
  "reasoning": "3-4 sentence explanation",
  "recommended_action": "PASS|REVIEW|REJECT"
}"""


def analyze_cross_documents(documents: dict) -> tuple:
    """
    Compare multiple documents against each other for inconsistencies.
    documents = {"bank_statement": "ocr text...", "payslip": "ocr text...", ...}
    Returns (info_dict, flags_list).
    """
    flags, info = [], {}

    if len(documents) < 2:
        return {"llm_cross_doc": "need_2_or_more_documents"}, []

    # Build combined prompt
    parts = []
    for doc_type, text in documents.items():
        if text and text.strip():
            truncated = text[:int(MAX_TEXT_CHARS / len(documents))]
            parts.append(f"=== {doc_type.upper().replace('_',' ')} ===\n{truncated}")

    if not parts:
        return {"llm_cross_doc": "no_text_available"}, []

    combined = "\n\n".join(parts)

    result = _call_claude(
        system_prompt = CROSS_DOC_SYSTEM,
        user_message  = f"Applicant documents:\n\n{combined}",
        max_tokens    = 1000,
    )

    if result.get("skipped") or result.get("error"):
        info["llm_cross_doc_status"] = result
        return info, []

    issues         = result.get("cross_document_issues", [])
    consistency    = result.get("overall_consistency", "consistent")
    assessment     = result.get("fraud_assessment", "genuine")
    recommended    = result.get("recommended_action", "PASS")

    info["llm_cross_doc_issues"]       = issues
    info["llm_cross_doc_consistency"]  = consistency
    info["llm_applicant_profile"]      = result.get("applicant_profile", {})
    info["llm_cross_doc_assessment"]   = assessment
    info["llm_cross_doc_reasoning"]    = result.get("reasoning", "")
    info["llm_recommended_action"]     = recommended

    high_severity  = [i for i in issues if i.get("severity") == "high"]
    salary_issues  = [i for i in issues if "salary" in i.get("issue_type","")]

    if assessment == "likely_fraudulent":
        flags.append("llm_cross_doc_likely_fraudulent")
    if consistency == "major_inconsistencies":
        flags.append("llm_cross_doc_major_inconsistencies")
    if high_severity:
        flags.append(f"llm_cross_doc_high_severity_issues:{len(high_severity)}")
    if salary_issues:
        flags.append("llm_salary_mismatch_detected")
    if recommended == "REJECT":
        flags.append("llm_recommends_reject")
    elif recommended == "REVIEW":
        flags.append("llm_recommends_review")

    # Extract income estimate for other checks
    profile = result.get("applicant_profile", {})
    if profile.get("likely_monthly_income"):
        try:
            income = float(str(profile["likely_monthly_income"]).replace(",",""))
            info["llm_estimated_monthly_income"] = income
        except Exception:
            pass

    return info, flags


# ═══════════════════════════════════════════════════════════════════════════════
#  3. FRAUD NARRATIVE REPORT
# ═══════════════════════════════════════════════════════════════════════════════

NARRATIVE_SYSTEM = """You are a senior compliance officer writing a brief fraud investigation report.
Given a list of fraud flags detected by automated systems, write a clear, professional narrative
explaining the risk in plain language that a loan officer can understand and act on.

Respond with valid JSON only:
{
  "executive_summary": "1-2 sentence summary for busy reviewers",
  "risk_narrative": "3-5 sentence explanation of what was found and why it matters",
  "key_concerns": ["list of top 3-5 specific concerns"],
  "recommended_actions": ["list of specific next steps for the loan officer"],
  "priority": "urgent|high|medium|low"
}"""


def generate_fraud_narrative(flags: list, doc_types: list, risk_score: int) -> dict:
    """
    Generate a human-readable fraud narrative from automated flags.
    Returns narrative dict.
    """
    if not LLM_ENABLED:
        return {"skipped": True}

    if not flags:
        return {
            "executive_summary": "No significant fraud indicators detected.",
            "risk_narrative":    "Automated screening found no material fraud signals in the submitted documents.",
            "key_concerns":      [],
            "recommended_actions": ["Standard processing may proceed."],
            "priority":          "low",
        }

    flag_list = "\n".join(f"- {f}" for f in flags[:30])
    prompt    = f"""Risk score: {risk_score}/200
Document types: {', '.join(doc_types)}
Automated flags detected:
{flag_list}

Write the fraud investigation report."""

    result = _call_claude(
        system_prompt = NARRATIVE_SYSTEM,
        user_message  = prompt,
        max_tokens    = 600,
    )

    if result.get("error") or result.get("skipped"):
        return result

    return result


# ═══════════════════════════════════════════════════════════════════════════════
#  SCORING WEIGHTS FOR LLM FLAGS
# ═══════════════════════════════════════════════════════════════════════════════

LLM_FLAG_WEIGHTS = {
    "llm_assessed_likely_fraudulent":      40,
    "llm_high_confidence_fraud":           20,
    "llm_assessed_suspicious":             20,
    "llm_multiple_inconsistencies":        15,
    "llm_inconsistencies_detected":         8,
    "llm_cross_doc_likely_fraudulent":     40,
    "llm_cross_doc_major_inconsistencies": 25,
    "llm_salary_mismatch_detected":        30,
    "llm_recommends_reject":               35,
    "llm_recommends_review":               15,
}
