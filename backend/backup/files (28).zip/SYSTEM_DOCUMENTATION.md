# KYC Fraud Detection System — Complete Documentation

**Version:** 2.0 | **Server:** 172.16.26.48 | **Stack:** FastAPI · Celery · PostgreSQL · Redis · Nginx · Docker

---

## 1. Access URLs

| URL | Description |
|-----|-------------|
| `http://172.16.26.48:3000/portal/` | Staff portal — main interface (login required) |
| `http://172.16.26.48:3000/portal/login` | Login page |
| `http://172.16.26.48:3000/dashboard/` | Analytics dashboard |
| `http://172.16.26.48:3000/docs` | Screening API docs (Swagger) |
| `http://172.16.26.48:3000/api/v1/docs` | Loan Integration API docs |
| `http://172.16.26.48:3000/webhook-dashboard/` | Webhook event log |
| `http://172.16.26.48:8000/` | Flower — Celery task monitor |

---

## 2. Staff Portal Features

### Dashboard
- Total screened, HIGH/MEDIUM/LOW counts last 30 days
- HIGH risk submissions this week with direct review links
- Quick action shortcuts to all major features

### Submit Document (`/portal/submit`)
| Form | Document | Speed |
|------|----------|-------|
| Screen PDF | Bank statement, payslip, tax, utility bill | Instant |
| Screen ID Card | National ID, passport + optional selfie | 20-60s async |
| Screen Image | Any document image | Instant |
| Poll Result | Enter task_id to check async job status | Live polling |

### Cases (`/portal/cases`)
- Searchable by applicant ID, risk level, doc type, period
- Filter: 7 / 30 / 90 days / 1 year
- Each row links to full forensic report

### Compliance Report (`/portal/report/{id}`)
- Risk banner with score and recommended action
- All forensic scores (ELA, hologram, template, ML, face)
- Complete fraud flag list
- Staff decision form with audit trail
- Download PDF button (regulator-ready format)

### Batch Processing (`/portal/batch`)
- Upload ZIP of ID card images named APPLICANT_ID.jpg
- All images queued automatically
- Results via webhook or Cases page

### Expiry Tracker (`/portal/expiry`)
- Expired IDs, expiring within 30 days, within 90 days, valid
- Direct link to each case report

### Duplicate Detection (`/portal/duplicates`)
- Same ID number appearing under different applicant names
- Grouped by ID number with risk levels
- Adjustable period: 30 / 90 / 365 days

### Export (`/portal/export`)
| Export | Format | Contents |
|--------|--------|----------|
| Cases to Excel | .xlsx | Colour-coded risk table + summary sheet |
| Cases to CSV | .csv | All fields, Excel/Sheets compatible |
| Monthly statistics | .xlsx | 12-month breakdown by risk and doc type |

### Admin (`/portal/admin`)
- Add / deactivate staff users
- Assign roles (admin / reviewer / viewer)
- Change any user's password
- Generate / revoke API keys (shown once — copy immediately)
- Test email configuration

---

## 3. Screening API

Base URL: `http://172.16.26.48:3000`
Interactive docs: `http://172.16.26.48:3000/docs`

### POST /screen-pdf
Screen a bank statement, payslip, tax document, or utility bill.

```bash
curl -X POST http://172.16.26.48:3000/screen-pdf \
  -H "X-API-Key: fds_your_key" \
  -F "file=@statement.pdf" \
  -F "applicant_id=APP-001"
```

Returns synchronous result with `risk.level`, `risk.score`, `risk.action`, `flags`, `banking_analysis`.

### POST /screen-image
Screen any document image (JPG, PNG, BMP, TIFF).

```bash
curl -X POST http://172.16.26.48:3000/screen-image \
  -F "file=@document.jpg" \
  -F "applicant_id=APP-001"
```

### POST /screen-id-card
Submit ID card or passport for async processing.

```bash
curl -X POST http://172.16.26.48:3000/screen-id-card \
  -F "file=@id_card.jpg" \
  -F "selfie=@selfie.jpg" \
  -F "applicant_id=APP-001" \
  -F "callback_url=http://your-system/webhook/kyc"
```

Returns `{"task_id": "...", "status": "queued"}`.

### GET /result/{task_id}
Poll for async ID card result.
States: `queued` | `processing` | `complete` | `failed`

### GET /history/{applicant_id}
All previous screenings for an applicant.

### Sample Full Result (ID Card)
```json
{
  "task_id": "d87c14c7-70cb-4dbe-a7be-4855b1c66280",
  "risk": {
    "level": "HIGH",
    "score": 95,
    "action": "REJECT",
    "flag_count": 8,
    "description": "Document shows strong indicators of tampering."
  },
  "flags": ["mrz_checksum_failed", "face_mismatch", "ml_high_tamper_probability"],
  "field_info": {
    "id_number": "123456789",
    "dob": "15/03/1990",
    "expiry_date": "2030-01-01",
    "mrz_checksum_ok": false
  },
  "ela": {"ela_mean_diff": 12.4, "ela_std_diff": 8.1},
  "hologram": {"holographic_patch_detected": false, "fft_peak_ratio": 2.1},
  "template_match": {
    "template_matched": "Cambodia National ID Card (New)",
    "keyword_ratio": 0.7,
    "khmer_detected": true
  },
  "face_match": {"face_match": false, "similarity_pct": 41.2},
  "ml_inference": {"ml_tamper_score": 0.89, "ml_prediction": "tampered", "ml_confidence": 0.78},
  "anomaly": {"is_anomaly": true, "anomaly_score": -0.62, "anomaly_severity": "high"},
  "network": {
    "network_connections": 2,
    "connected_applicants": [{"applicant_id": "APP-009", "link_types": ["phone"]}]
  },
  "llm_analysis": {
    "llm_assessment": "suspicious",
    "llm_reasoning": "Date of birth on MRZ does not match printed date. Font inconsistency detected in name field.",
    "llm_fraud_signals": ["mrz_dob_mismatch", "font_inconsistency"]
  },
  "banking_analysis": {}
}
```

---

## 4. Loan Integration API

Base URL: `http://172.16.26.48:3000/api/v1`
Interactive docs: `http://172.16.26.48:3000/api/v1/docs`

Designed for loan origination systems. Submit all documents in one call, get a unified risk decision.

### POST /api/v1/loan-case

**Form fields:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `loan_ref` | string | Yes | Unique loan reference number |
| `applicant_id` | string | Yes | Your applicant/customer ID |
| `applicant_name` | string | No | Full name |
| `loan_type` | string | No | Personal / Mortgage / SME |
| `loan_amount` | string | No | Requested amount |
| `id_card` | file | No | National ID or passport image |
| `selfie` | file | No | Selfie for face matching |
| `bank_statement` | file | No | Bank statement PDF |
| `payslip` | file | No | Payslip PDF or image |
| `utility_bill` | file | No | Utility bill PDF or image |
| `other_doc` | file | No | Any other supporting document |
| `callback_url` | string | No | Webhook URL for result notification |
| `source_system` | string | No | Name of calling system |

**At least one document is required.**

```bash
curl -X POST http://172.16.26.48:3000/api/v1/loan-case \
  -H "X-API-Key: fds_your_key" \
  -F "loan_ref=LOAN-2024-001" \
  -F "applicant_id=APP-001" \
  -F "applicant_name=Dara Sok" \
  -F "loan_type=Personal Loan" \
  -F "loan_amount=50000" \
  -F "source_system=LoanSystem_v2" \
  -F "id_card=@id_card.jpg" \
  -F "selfie=@selfie.jpg" \
  -F "bank_statement=@statement.pdf" \
  -F "payslip=@payslip.pdf" \
  -F "callback_url=http://your-system/webhook/kyc"
```

**Response:**
```json
{
  "loan_ref": "LOAN-2024-001",
  "applicant_id": "APP-001",
  "applicant_name": "Dara Sok",
  "screened_at": "2024-01-15T08:30:00Z",
  "completed_at": "2024-01-15T08:31:05Z",
  "overall": {
    "risk_level": "MEDIUM",
    "risk_score": 35,
    "action": "REVIEW",
    "document_count": 4,
    "flag_count": 6,
    "description": "Some documents require manual verification before proceeding.",
    "flags": ["balance_math_inconsistency", "salary_is_round_number"]
  },
  "documents": {
    "id_card": {
      "risk_level": "LOW", "risk_score": 10, "action": "PASS",
      "field_info": {"id_number": "123456789", "dob": "15/03/1990"}
    },
    "bank_statement": {
      "risk_level": "MEDIUM", "risk_score": 35, "action": "REVIEW",
      "flags": ["balance_math_inconsistency", "excessive_round_numbers"]
    },
    "payslip": {
      "risk_level": "LOW", "risk_score": 8, "action": "PASS"
    }
  }
}
```

**Risk Aggregation Rules:**

| Condition | Overall | Action |
|-----------|---------|--------|
| Any document = HIGH | HIGH | REJECT |
| 2+ documents = MEDIUM | HIGH | REJECT |
| Exactly 1 document = MEDIUM | MEDIUM | REVIEW |
| All documents = LOW | LOW | PASS |

### GET /api/v1/loan-case/{loan_ref}
Retrieve result for a previously submitted loan case.

### GET /api/v1/loan-cases?days=30&limit=50
List recent loan cases.

### Python Integration Example
```python
import requests

def screen_loan(loan_ref, applicant_id, id_path, statement_path, payslip_path):
    return requests.post(
        "http://172.16.26.48:3000/api/v1/loan-case",
        headers={"X-API-Key": "fds_your_key"},
        data={
            "loan_ref":      loan_ref,
            "applicant_id":  applicant_id,
            "source_system": "LoanOriginationSystem",
            "callback_url":  "http://your-system/webhook/kyc",
        },
        files={
            "id_card":        open(id_path, "rb"),
            "bank_statement": open(statement_path, "rb"),
            "payslip":        open(payslip_path, "rb"),
        },
        timeout=120,
    ).json()

result = screen_loan("LOAN-001", "APP-001", "id.jpg", "statement.pdf", "payslip.pdf")
print(result["overall"]["action"])  # PASS / REVIEW / REJECT
```

---

## 5. AI Intelligence Layers

| Layer | Technology | File | What It Detects |
|-------|------------|------|-----------------|
| 1 | Classical CV (OpenCV + SIFT) | screening.py | Copy-move, blur, colour delta, OCR |
| 2 | Statistical forensics | screening.py | ELA tampering, FFT patterns, noise variance |
| 3 | Custom ML (MobileNetV2) | ml_trainer.py | Genuine vs tampered Cambodia IDs |
| 4 | Face AI (DeepFace ArcFace) | face_match.py | Face mismatch, liveness detection |
| 5 | Rule engine | screening.py | MRZ checksum, velocity, expiry, templates |
| 6 | Banking PDF intelligence | pdf_banking.py | Balance math, Benford, structuring, salary |
| 7 | LLM reasoning (Claude API) | llm_analyzer.py | Cross-document inconsistencies, narrative |
| 8 | Anomaly detection | anomaly_detect.py | Documents unlike historical genuine set |
| 9 | Fraud network graph | fraud_network.py | Shared phones, emails, accounts across applicants |

---

## 6. Document Types Supported

| Document | All Layers | Special Checks |
|----------|-----------|----------------|
| KHM National ID (new, biometric) | Yes | MRZ TD1, hologram, Khmer OCR, auto-rotate |
| KHM National ID (old, pre-2020) | Yes | No MRZ expected — flagged if found |
| KHM Passport | Yes | MRZ TD3 checksum |
| Generic Passport | Yes | MRZ TD3 checksum |
| Bank Statement PDF | Forensics + banking | Balance, Benford, structuring, template fingerprint |
| Payslip PDF / image | Forensics + banking | Gross/net validation, deduction rate, employer |
| Tax Document PDF | Forensics + banking | Transaction patterns, date sequence |
| Utility Bill PDF / image | Forensics | Address extraction, tampering |
| General Image | Forensics | ELA, copy-move, metadata |

---

## 7. Risk Scoring

| Score | Level | Action |
|-------|-------|--------|
| 0-19 | LOW | PASS — proceed normally |
| 20-49 | MEDIUM | REVIEW — manual verification recommended |
| 50+ | HIGH | REJECT — investigate before proceeding |

**Top flag weights:**

| Flag | Score |
|------|-------|
| `fraud_ring_suspected` | +45 |
| `llm_assessed_likely_fraudulent` | +40 |
| `ml_high_tamper_probability` | +40 |
| `shared_bank_account` | +35 |
| `balance_math_inconsistency` | +35 |
| `face_mismatch` | +35 |
| `template_shared_across_applicants` | +35 |
| `llm_recommends_reject` | +35 |
| `benfords_law_violation` | +30 |
| `structuring_near_10000` | +30 |
| `shared_phone_number` | +30 |
| `mrz_checksum_failed` | +30 |
| `network_connections_detected` | +25 |
| `liveness_failed` | +25 |
| `future_dates_detected` | +25 |

---

## 8. Webhook Integration

Provide `callback_url` in any API call to receive results automatically when processing completes.

**Webhook payload (loan case):**
```json
{
  "event": "loan_case.complete",
  "loan_ref": "LOAN-2024-001",
  "applicant_id": "APP-001",
  "overall_risk": "HIGH",
  "overall_action": "REJECT",
  "overall_score": 95,
  "document_count": 4,
  "flags": ["balance_math_inconsistency", "fraud_ring_suspected"],
  "detail": { "...full result..." }
}
```

**Test endpoint:**
```bash
curl -X POST http://172.16.26.48:3000/webhook/kyc \
  -H "Content-Type: application/json" \
  -d '{"event":"test","task_id":"manual-test"}'
```

**View received webhooks:** `http://172.16.26.48:3000/webhook-dashboard/`

---

## 9. User Roles and Permissions

| Permission | Admin | Reviewer | Viewer |
|-----------|-------|----------|--------|
| View all cases and reports | Yes | Yes | Yes |
| Submit documents for screening | Yes | Yes | No |
| Add staff decisions and notes | Yes | Yes | No |
| Export data to Excel/CSV | Yes | Yes | No |
| Manage staff users | Yes | No | No |
| Generate / revoke API keys | Yes | No | No |
| Change user passwords | Yes | No | No |

**Default accounts — change immediately via Admin page:**

| Username | Password | Role |
|----------|----------|------|
| admin | admin123 | Admin |
| reviewer | review123 | Reviewer |
| viewer | viewer123 | Viewer |

---

## 10. API Authentication

Enable: set `API_AUTH_ENABLED=true` in `.env` on the server.

Generate keys via Admin page (`/portal/admin`). Keys are shown only once.

Format: `fds_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

```bash
# Include in every API request
-H "X-API-Key: fds_your_key"
# Or as Bearer token
-H "Authorization: Bearer fds_your_key"
```

---

## 11. Email Alerts

Configure in `.env`:
```
ALERTS_ENABLED=true
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@gmail.com
SMTP_PASSWORD=your_app_password
ALERT_TO=fraud@bank.com,compliance@bank.com
SERVER_IP=172.16.26.48
```

- Instant email on every HIGH risk detection
- Daily digest: `docker exec backend-api-1 python -c "from alerts import send_daily_digest; send_daily_digest()"`

---

## 12. ML Model Training

```bash
# One-time setup
docker exec backend-api-1 python ml_trainer.py setup

# Copy training images
docker cp genuine_id.jpg backend-api-1:/app/ml_data/genuine/
docker cp fake_id.jpg backend-api-1:/app/ml_data/tampered/

# Train (takes 5-10 minutes on CPU)
docker exec backend-api-1 python ml_trainer.py train

# Check results
docker exec backend-api-1 python ml_trainer.py evaluate

# Test on single image
docker exec backend-api-1 python ml_trainer.py test /app/test_files/id.jpg

# Reload workers to use new model
docker compose restart worker-idcard
```

Recommended: 50+ images per class. System uses 50x augmentation so even 3 images will train but with limited accuracy.

**Train anomaly detector** (needs 30+ genuine screenings in DB):
```bash
docker exec backend-api-1 python -c "
from anomaly_detect import train_anomaly_detector
print(train_anomaly_detector(min_samples=30))
"
```

---

## 13. Operations Reference

```bash
# Start / stop
make up
make down
make build   # rebuild after requirements.txt or Dockerfile changes

# Status and logs
make ps
make log svc=api
make log svc=worker-idcard
make log svc=worker-pdf
make log svc=portal

# Deploy code change (no new packages)
git pull
docker cp <file> backend-api-1:/app/<file>
docker compose restart api

# Deploy code change (new packages added)
git pull && make down && make build && make up

# Database
docker exec -it backend-postgres-1 psql -U docuser -d fraud_detect

# Health check
curl http://172.16.26.48:3000/
curl http://172.16.26.48:3000/api/v1/
```

**Never edit files directly on server** (except `.env`). Always: edit locally → commit → push → git pull on server.

---

## 14. Feature Status

| Feature | Status |
|---------|--------|
| PDF screening | Live |
| Image screening | Live |
| ID card screening (async + webhook) | Live |
| Cambodia ID templates (old + new + passport) | Live |
| Khmer OCR | Live |
| Auto-rotate portrait ID photos | Live |
| Face match + liveness | Live |
| Banking PDF intelligence (9 checks) | Live |
| Benford's Law analysis | Live |
| Balance consistency check | Live |
| Structuring detection | Live |
| Template fingerprinting | Live |
| Staff portal with login | Live |
| Role-based access (admin/reviewer/viewer) | Live |
| Compliance PDF reports | Live |
| Excel/CSV export | Live |
| Email alerts | Live — enable ALERTS_ENABLED=true |
| Webhook integration | Live |
| Batch ZIP processing | Live |
| Loan Integration API | Live |
| Duplicate ID detection | Live |
| Expiry tracker | Live |
| Fraud network detection | Live |
| Anomaly detection | Live — needs 30+ genuine screenings |
| ML classifier (MobileNetV2) | Live — retrain with more images |
| LLM document reasoning | Built — enable LLM_ANALYSIS_ENABLED=true |
| Fraud network visualisation | Planned |
| SMS alerts | Planned |
| Thailand / Vietnam templates | Planned |
| Core banking system integration | Planned |

---

## 15. Database Architecture

### Overview
All services share one PostgreSQL database: `fraud_detect`.

```
.env  →  DATABASE_URL=postgresql://docuser:password@postgres:5432/fraud_detect
  ↓
Each Docker container reads .env via env_file: .env
  ↓
load_dotenv() in Python reads DATABASE_URL
  ↓
SQLAlchemy create_engine(DATABASE_URL) — one engine per service
  ↓
Connection pool (5-10 connections per service, auto-reconnect)
  ↓
PostgreSQL 16 — database: fraud_detect
```

### Database Tables

**KYC System tables** (created by `database.py`):

| Table | Purpose | Key columns |
|-------|---------|-------------|
| `screening_logs` | Every document screened | file_name, doc_type, risk_level, risk_score, flags, full_result, applicant_id |
| `velocity_events` | Duplicate/rapid submission tracking | id_number, file_sha256, risk_level, submitted_at |
| `staff_users` | KYC portal login accounts | username, password (hashed), role, active |
| `api_keys` | API key authentication | key_hash, key_prefix, active, last_used |

**Loan Portal tables** (created by `loan_db.py`):

| Table | Purpose | Key columns |
|-------|---------|-------------|
| `loan_applications` | Full loan application records | loan_ref, applicant details, kyc_result, status, decision |
| `loan_officers` | Loan portal login accounts | username, password (hashed), role |
| `loan_comments` | Audit trail per loan case | loan_ref, author, comment |
| `loan_cases` | KYC API results per loan | loan_ref, overall_risk, documents JSON |

**Fraud network tables** (created by `fraud_network.py`):

| Table | Purpose |
|-------|---------|
| `fraud_network_links` | Links between applicants sharing attributes |
| `applicant_attributes` | Extracted phone/email/address per applicant |

### Connection String Format
```
postgresql://USERNAME:PASSWORD@HOST:PORT/DATABASE
postgresql://docuser:Bank%402025@postgres:5432/fraud_detect
             ↑         ↑           ↑      ↑     ↑
             user    password    container port  database name
                     (%40 = @ encoded)
```

### Why All Services Share One Database
- `screening_logs` is written by workers and read by portal/dashboard/loan-portal
- `staff_users` is managed by portal and checked on every login
- `loan_applications` links to `screening_logs` via `applicant_id`
- The fraud network tables are written during ID card screening and read by the portal

### Troubleshooting Database Issues
```bash
# Check database exists
docker exec backend-postgres-1 psql -U docuser -l

# Check tables exist
docker exec backend-postgres-1 psql -U docuser -d fraud_detect -c "\dt"

# Check what URL a service sees
docker exec backend-api-1 env | grep DATABASE_URL

# Recreate tables (WARNING: deletes all data)
docker exec backend-postgres-1 psql -U docuser -d fraud_detect \
  -c "DROP TABLE IF EXISTS screening_logs CASCADE;"
docker compose restart api
```

---

## 16. Loan Officer Portal

A separate portal for loan officers to manage loan applications with automatic KYC integration.

**Access:** `http://172.16.26.48:3000/loan/`

**Default accounts:**

| Username | Password | Role | Can Do |
|----------|----------|------|--------|
| officer | officer123 | Officer | Submit + view cases |
| manager | manager123 | Manager | Submit + view + approve/reject |
| admin | admin123 | Admin | Full access + manage officers |

### Features

**New Application (`/loan/new`)**
- Full loan application form — all loan types
- Upload all supporting documents in one form
- Clicking Submit automatically calls KYC API and waits for result
- Save as Draft option for incomplete applications

**Pipeline View (`/loan/pipeline`)**
Kanban board showing all cases by status:
- Draft → Submitted → KYC Screening → Pending Review → Approved / Rejected

**Case View (`/loan/case/{loan_ref}`)**
- Full applicant and loan details
- KYC risk result with per-document breakdown
- All fraud flags from KYC system
- Decision form (managers only) — Approve / Reject / Request More Info
- Interest rate field for approved loans
- Comment thread for audit trail

**Cases List (`/loan/cases`)**
- Filter by status: Draft / Screening / Review / Approved / Rejected
- Search by reference, applicant name, amount

**Search (`/loan/search`)**
- Search across all cases by name, applicant ID, loan reference, or phone number

**Admin (`/loan/admin`)**
- Add loan officers with role assignment
- Change passwords

### Loan Application Workflow

```
Officer fills form → Documents uploaded → KYC API called automatically
        ↓
KYC result received (risk level + flags per document)
        ↓
Case moves to "Pending Review" status
        ↓
Manager reviews KYC result → Makes decision (Approve/Reject/Request more)
        ↓
Decision recorded with notes → Audit trail updated
```

### Supported Loan Types
- Personal Loan
- Business / SME Loan
- Mortgage / Home Loan
- Vehicle Loan
- Education Loan
- Agricultural Loan

### Integration with KYC System
When a loan officer submits an application, the loan portal automatically:
1. Calls `POST /api/v1/loan-case` with all uploaded documents
2. Waits up to 60 seconds for the KYC result
3. Stores the full result in `loan_applications.kyc_result`
4. Updates the case status based on KYC recommendation
5. The KYC webhook URL (`/loan/webhook/kyc-result`) receives async updates

---

*Document updated: April 2026 | Version 2.1 | Confidential — Internal use only*

---

## 17. Applicant Self-Service Portal

A bilingual customer-facing portal where applicants submit their own loan applications and track status — no branch visit required.

**Access:** `http://172.16.26.48:3000/apply/`

### Language Support
Full Khmer and English support throughout. Language toggle button in the top-right corner switches all labels, buttons, status messages, and instructions. Language preference saved in browser cookie.

### Login Options
Applicants can sign in two ways:

| Method | How it works |
|--------|-------------|
| Phone + OTP | Enter phone number → receive 6-digit code → instant access |
| Email + Password | Standard login with registered email and password |

New applicants register with name, email, and password. Phone number is optional.

In development mode (`DEV_MODE=true` in `.env`) the OTP code is shown in the response for testing. Set `DEV_MODE=false` in production.

### Applicant Features

**Dashboard (`/apply/`)**
- List of all submitted applications
- Status pill for each (Draft / Submitted / Screening / Review / Approved / Rejected)
- Quick link to start new application

**New Application (`/apply/new`)**
- Personal information (pre-filled from previous applications)
- Loan details: type, amount, term, purpose
- Document upload: ID card, selfie, bank statement, payslip, utility bill
- Submit → documents instantly sent to KYC screening system
- Save as Draft → return and complete later

**Application Status (`/apply/case/{ref}`)**
- Visual progress steps: Submitted → Screening → Review → Approved
- Colour-coded progress bar
- Status message in applicant's language explaining what's happening
- Documents uploaded list
- Decision notes when loan is approved or rejected

### Application Workflow (Applicant View)

```
Applicant registers / logs in
        ↓
Fills loan application form + uploads documents
        ↓
Clicks Submit → KYC screening runs automatically (background)
        ↓
Status: "Submitted" → "Screening" → "Under Review"
        ↓
Loan officer reviews in Loan Officer Portal
        ↓
Status: "Approved" ✓ or "Rejected" ✗
        ↓
Applicant sees decision + notes on status page
```

### Database Tables (created automatically)

| Table | Purpose |
|-------|---------|
| `applicants` | Applicant accounts — phone, email, password hash, profile |
| `applicant_loans` | Loan applications with KYC results and decision |

### Supported Loan Types (both languages)
| English | Khmer |
|---------|-------|
| Personal Loan | ប្រាក់កម្ចីផ្ទាល់ខ្លួន |
| Business / SME Loan | ប្រាក់កម្ចីអាជីវកម្ម |
| Mortgage / Home Loan | ប្រាក់កម្ចីទិញផ្ទះ |
| Vehicle Loan | ប្រាក់កម្ចីទិញយានយន្ត |
| Education Loan | ប្រាក់កម្ចីសិក្សា |
| Agricultural Loan | ប្រាក់កម្ចីកសិកម្ម |

---

## 18. Complete System Summary

### All Portals and URLs

| URL | Portal | Users | Purpose |
|-----|--------|-------|---------|
| `:3000/portal/` | KYC Staff Portal | KYC analysts | Screen documents, view fraud reports |
| `:3000/loan/` | Loan Officer Portal | Loan officers | Manage loan applications, make decisions |
| `:3000/apply/` | Applicant Portal | Bank customers | Submit applications, track status |
| `:3000/dashboard/` | Analytics Dashboard | Management | Fraud trends and statistics |
| `:3000/docs` | API Docs (Swagger) | Developers | Test screening API |
| `:3000/api/v1/docs` | Loan API Docs | Developers | Test loan integration API |
| `:3000/webhook-dashboard/` | Webhook Log | Developers | View webhook events |
| `:8000/` | Flower | Operations | Celery task monitor |

### All Services (Docker containers)

| Container | Port | Purpose |
|-----------|------|---------|
| `backend-api-1` | 8001 | Main screening API |
| `backend-worker-pdf-1` | — | PDF screening worker |
| `backend-worker-image-1` | — | Image screening worker |
| `backend-worker-idcard-1` | — | ID card screening worker |
| `backend-portal-1` | 8003 | KYC staff portal |
| `backend-loan-portal-1` | 8005 | Loan officer portal |
| `backend-applicant-portal-1` | 8006 | Applicant self-service portal |
| `backend-loan-api-1` | 8004 | Loan integration API |
| `backend-dashboard-1` | 8002 | Analytics dashboard |
| `backend-webhook-1` | 8001 | Webhook receiver |
| `backend-flower-1` | 8000 | Celery monitor |
| `backend-nginx-1` | 3000 | Reverse proxy (public) |
| `backend-postgres-1` | 5432 | PostgreSQL database |
| `backend-redis-1` | 6379 | Redis broker + cache |

### All Database Tables

| Table | Owner | Purpose |
|-------|-------|---------|
| `screening_logs` | KYC system | Every document screened |
| `velocity_events` | KYC system | Duplicate/rapid submission tracking |
| `staff_users` | KYC portal | KYC analyst accounts |
| `api_keys` | KYC system | API key authentication |
| `loan_applications` | Loan officer portal | Full loan case records |
| `loan_officers` | Loan officer portal | Loan officer accounts |
| `loan_comments` | Loan officer portal | Audit trail comments per case |
| `loan_cases` | Loan integration API | KYC API results per loan |
| `applicants` | Applicant portal | Customer accounts |
| `applicant_loans` | Applicant portal | Customer loan applications |
| `fraud_network_links` | Fraud network | Links between connected applicants |
| `applicant_attributes` | Fraud network | Extracted phone/email/address |
| `loan_officers` (loan_db) | Loan portal | Separate officer auth table |

### All Source Files

| File | Purpose |
|------|---------|
| `app.py` | Main FastAPI screening API |
| `tasks.py` | Celery async tasks (ID card screening) |
| `screening.py` | Core document screening logic |
| `database.py` | PostgreSQL models and helpers |
| `celery_app.py` | Celery + Redis configuration |
| `pdf_banking.py` | Banking PDF intelligence (9 checks) |
| `ml_trainer.py` | ML model training (MobileNetV2) |
| `face_match.py` | Face matching + liveness (DeepFace) |
| `hologram.py` | Hologram detection |
| `template_match.py` | Cambodia ID template matching |
| `llm_analyzer.py` | Claude API document reasoning |
| `anomaly_detect.py` | Isolation Forest anomaly detection |
| `fraud_network.py` | Graph-based fraud ring detection |
| `duplicate_detect.py` | Duplicate identity detection |
| `alerts.py` | Email alert system |
| `report_gen.py` | PDF compliance report generator |
| `export.py` | Excel/CSV export |
| `auth.py` | KYC portal JWT authentication |
| `api_keys.py` | API key management |
| `portal.py` | KYC staff portal (FastAPI app) |
| `dashboard.py` | Analytics dashboard (FastAPI app) |
| `loan_portal.py` | Loan officer portal (FastAPI app) |
| `loan_db.py` | Loan portal database models |
| `loan_integration.py` | Loan integration API (FastAPI app) |
| `applicant_portal.py` | Applicant self-service portal |
| `webhook_receiver.py` | Webhook event receiver |

### Environment Variables Reference (`.env`)

```bash
# Database
DATABASE_URL=postgresql://docuser:Bank%402025@postgres:5432/fraud_detect

# Redis
REDIS_URL=redis://redis:6379/0

# OCR
TESSERACT_CMD=/usr/bin/tesseract

# Auth
JWT_SECRET=your_random_secret_string
SESSION_HOURS=8

# Email alerts
ALERTS_ENABLED=false
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@gmail.com
SMTP_PASSWORD=your_app_password
ALERT_FROM=kyc@yourbank.com
ALERT_TO=fraud@bank.com,compliance@bank.com
SERVER_IP=172.16.26.48

# API authentication
API_AUTH_ENABLED=false

# LLM reasoning (Claude API)
LLM_ANALYSIS_ENABLED=false

# Flower monitor
FLOWER_USER=admin
FLOWER_PASSWORD=flowerpass

# Webhooks
WEBHOOK_SECRET=changeme_secret_123

# Applicant portal
DEV_MODE=true
SMS_ENABLED=false

# Loan portal
KYC_API_URL=http://api:8001
KYC_PORTAL_URL=http://172.16.26.48:3000/dashboard/
```

### Default Login Credentials (change all immediately)

| Portal | Username | Password | Role |
|--------|----------|----------|------|
| KYC Portal | admin | admin123 | Admin |
| KYC Portal | reviewer | review123 | Reviewer |
| KYC Portal | viewer | viewer123 | Viewer |
| Loan Portal | admin | admin123 | Admin |
| Loan Portal | manager | manager123 | Manager |
| Loan Portal | officer | officer123 | Officer |
| Flower | admin | flowerpass | — |

### Feature Status (as of April 2026)

| Feature | Status |
|---------|--------|
| PDF screening with banking intelligence | Live |
| Image screening | Live |
| ID card screening (async + webhook) | Live |
| Cambodia ID templates (old + new + passport) | Live |
| Khmer OCR (tesseract-ocr-khm) | Live |
| Auto-rotate portrait ID photos | Live |
| Face match + liveness (DeepFace ArcFace) | Live |
| MRZ checksum validation (TD1 + TD3) | Live |
| Hologram detection | Live |
| ELA tampering analysis | Live |
| Benford's Law analysis | Live |
| Balance consistency check | Live |
| Structuring detection | Live |
| Template fingerprinting across applicants | Live |
| Salary/payslip validation | Live |
| ML classifier (MobileNetV2, 50x augmentation) | Live — retrain with more images |
| Anomaly detection (Isolation Forest) | Live — needs 30+ genuine screenings |
| Fraud network detection | Live |
| Duplicate ID detection | Live |
| Velocity checks (duplicate submissions) | Live |
| KYC staff portal with login + roles | Live |
| Compliance PDF reports | Live |
| Excel/CSV export | Live |
| Email alerts on HIGH risk | Live — enable ALERTS_ENABLED=true |
| Daily digest email | Live — run via script |
| Webhook integration | Live |
| Batch ZIP processing | Live |
| Expiry tracker | Live |
| Analytics dashboard | Live |
| Loan Integration API (/api/v1/) | Live |
| Loan Officer Portal (/loan/) | Live |
| Applicant Self-Service Portal (/apply/) | Live |
| Bilingual UI (Khmer + English) | Live |
| Phone OTP login | Live (DEV_MODE shows OTP) |
| LLM document reasoning (Claude API) | Built — enable LLM_ANALYSIS_ENABLED=true |
| SMS notifications to applicants | Built — enable SMS_ENABLED=true + configure provider |
| Automated decision engine | Planned |
| Fraud network graph visualisation | Planned |
| Cambodia government ID verification API | Planned |
| Core banking system integration | Planned |
| Additional country templates (Thailand, Vietnam) | Planned |

---

*Document updated: April 2026 | Version 3.0 | Confidential — Internal use only*

---

## 19. Real-time Fraud Intelligence Dashboard (v2)

**Access:** `http://172.16.26.48:3000/dashboard/`

Completely rebuilt dashboard with live charts and auto-refresh every 30 seconds.

### Features

**5 stat cards** — Total screened, HIGH/MEDIUM/LOW counts with 24h spike indicator, average risk score, unique applicants.

**Risk trend chart** — Stacked bar chart by day (HIGH/MEDIUM/LOW volumes) with average score line on second axis. Shows fraud spikes as they happen.

**Risk split donut** — Percentage breakdown for the selected period with labels.

**Top fraud flags** — 12 most triggered flags ranked by frequency with colour-coded fill bars. Tells you which checks catch the most fraud.

**Hourly heatmap** — 24 cells showing submission volume by hour. Red tint = HIGH risk hours, blue = normal volume. Reveals if fraud attempts cluster at specific times.

**Score distribution histogram** — How risk scores are distributed across the 0–75+ range.

**Recent screenings live feed** — Last 12 submissions with file name, type, applicant ID, risk badge, score, and time.

**Velocity alerts** — Applicants with 2+ submissions in 7 days. Repeated HIGH risk is a strong fraud signal.

**Doc type breakdown** — Total vs HIGH risk by document type (id\_card, pdf, image).

### API Endpoints (used by dashboard JS)

| Endpoint | Returns |
|----------|---------|
| `GET /dashboard/api/stats?days=30` | Summary statistics |
| `GET /dashboard/api/trend?days=30` | Daily risk counts |
| `GET /dashboard/api/flags?days=30` | Top fraud flags |
| `GET /dashboard/api/hourly` | Submissions by hour (7 days) |
| `GET /dashboard/api/recent` | Last 12 screenings |
| `GET /dashboard/api/risk-distribution` | Score distribution buckets |
| `GET /dashboard/api/doc-types` | Breakdown by document type |
| `GET /dashboard/api/velocity` | Repeated submission applicants |

Period selector: 7 / 30 / 90 days. Auto-refreshes every 30 seconds.

---

## 20. SMS Notification System

**File:** `sms_notifications.py`
**Provider:** Twilio
**Trigger:** Automatic on loan status changes

### Setup

```bash
# Add to .env
SMS_ENABLED=true
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_FROM_NUMBER=+12025551234
BANK_NAME=Your Bank Name
BANK_PHONE=+855 xx xxx xxx
```

Sign up at `https://www.twilio.com/try-twilio` — free $15 trial credit (~1,700 SMS).
Upgrade account ($20 minimum) to remove 5 messages/day trial limit.

### Events That Trigger SMS

| Event | When | Both Languages |
|-------|------|----------------|
| Application received | Applicant submits via `/apply/` | Yes |
| Screening started | KYC processing begins | Yes |
| Approved | Loan officer approves OR KYC = PASS | Yes |
| Rejected | Loan officer rejects OR KYC = REJECT | Yes |
| Review needed | KYC = MEDIUM risk | Yes |
| OTP code | Phone login verification | Yes |

### Message Examples

English approval:
```
YourBank: Congratulations! Your loan application AP2604173144
for $5,000 has been APPROVED. Our team will contact you
within 2 business days. Questions? Call: +855 xx xxx xxx
```

Khmer approval:
```
YourBank: សូមអបអរ! ពាក្យសុំប្រាក់កម្ចី AP2604173144
ចំនួន $5,000 បានទទួល អនុម័ត។ ក្រុមការងារយើងនឹងទាក់ទង
អ្នកក្នុង ២ ថ្ងៃធ្វើការ។
```

Language matches applicant's portal language preference automatically.

### Test SMS

```bash
docker exec backend-loan-portal-1 python sms_notifications.py +855xxxxxxxxx en
docker exec backend-loan-portal-1 python sms_notifications.py +855xxxxxxxxx km
```

### Integration Points

SMS fires automatically from:
- `applicant_portal.py` — on submission and KYC completion
- `loan_portal.py` — when officer clicks Approve/Reject

All SMS failures are non-fatal — logged as warnings, never break the loan flow.

---

## 21. Document Training Pipeline

Two training scripts for processing your document collection and improving AI accuracy.

### Files
- `train_targeted.py` — optimised for large datasets (65,000+ docs), with progress bar and ETA
- `train_pipeline.py` — full pipeline with interactive manual review

### Database Table
`training_documents` — stores all processed documents with labels, risk scores, and full forensic results.

### Stage Overview

| Stage | Command | What it does |
|-------|---------|--------------|
| Scan | `train_targeted.py scan` | Analyse folder contents, estimate processing time |
| Images | `train_targeted.py images` | Process all JPG/PNG through KYC engine |
| PDFs | `train_targeted.py pdfs` | Process bank statements, CBC, payslips |
| Train ML | `train_targeted.py train` | Train MobileNetV2 classifier |
| Anomaly | `train_targeted.py anomaly` | Retrain Isolation Forest |
| Report | `train_targeted.py report` | Show results and model status |

### Auto-labeling Rules

| Condition | Label |
|-----------|-------|
| Risk score ≥ 50 | tampered |
| Risk score ≤ 20 | genuine |
| Risk score 21–49 | uncertain (needs manual review) |
| Contains definitive flag | tampered (overrides score) |

Definitive flags that always mean tampered: `mrz_checksum_failed`, `face_mismatch`, `balance_math_inconsistency`, `benfords_law_violation`, `template_shared_across_applicants`, `future_dates_detected`.

### Running the Pipeline

```bash
# Copy script to container
docker cp ~/apps/Ai_Projects/backend/train_targeted.py backend-api-1:/app/train_targeted.py

# Step 1 — scan folder (instant, no processing)
docker exec backend-api-1 python train_targeted.py scan

# Step 2 — process images (~1,000 docs, ~1 minute)
docker exec backend-api-1 python train_targeted.py images

# Step 3 — process banking PDFs
docker exec backend-api-1 python train_targeted.py pdfs

# Step 4 — train ML classifier (needs tampered samples)
docker exec backend-api-1 python train_targeted.py train --doc-type id_card

# Step 5 — train anomaly detector (genuine docs only, min 30)
docker exec backend-api-1 python train_targeted.py anomaly

# Step 6 — view results
docker exec backend-api-1 python train_targeted.py report

# Step 7 — reload workers
docker compose restart worker-idcard
```

### Pipeline is Resumable

If processing stops at any point, run the same command again. Already-processed files are skipped automatically based on file path stored in `training_documents`.

### Mounting the Data Folder

To access documents stored outside the container, add to `docker-compose.yml`:

```yaml
  api:
    volumes:
      - uploads:/app/uploads
      - /DATA:/DATA:ro      # add this line
```

Then restart: `docker compose up -d --no-deps api`

---

## 22. Anomaly Detection (Trained)

**File:** `anomaly_detect.py`
**Algorithm:** Isolation Forest (scikit-learn)
**Status:** Trained on 500 genuine customer documents

### How It Works

The Isolation Forest learns what your genuine customer documents look like — their ELA scores, noise patterns, sharpness ratios, template match quality, and flag distributions. When a new document arrives that looks statistically different from this baseline, it gets flagged as an anomaly.

This catches fraud patterns the rule-based system has never seen before — new forgery techniques, unusual document sources, or statistical outliers that don't trigger specific rules.

### Training

```bash
# Retrain after collecting more genuine documents
docker exec backend-api-1 python train_targeted.py anomaly

# Copy model to all workers
for svc in worker-pdf worker-image worker-idcard; do
    docker exec backend-${svc}-1 mkdir -p /app/ml_models
    docker cp backend-api-1:/app/ml_models/anomaly_detector.pkl backend-${svc}-1:/app/ml_models/
    docker cp backend-api-1:/app/ml_models/anomaly_detector_meta.json backend-${svc}-1:/app/ml_models/
done
docker compose restart worker-idcard worker-pdf worker-image
```

### Output in Screening Results

```json
"anomaly": {
  "is_anomaly": true,
  "anomaly_score": -0.62,
  "anomaly_threshold": -0.50,
  "anomaly_severity": "high",
  "training_samples": 500
}
```

Adds flags: `anomaly_detected:high` (+30 score) or `anomaly_detected:medium` (+15 score).

### Retrain Schedule

Retrain monthly as you collect more genuine screenings. The more genuine documents in the baseline, the more accurate anomaly detection becomes.

---

## 23. Complete File Reference (Updated)

| File | Purpose | Status |
|------|---------|--------|
| `app.py` | Main FastAPI screening API | Live |
| `tasks.py` | Celery async tasks | Live |
| `screening.py` | Core document screening logic | Live |
| `database.py` | PostgreSQL models and helpers | Live |
| `celery_app.py` | Celery + Redis configuration | Live |
| `pdf_banking.py` | Banking PDF intelligence (9 checks) | Live |
| `ml_trainer.py` | ML model training (MobileNetV2) | Live |
| `face_match.py` | Face matching + liveness (DeepFace) | Live |
| `hologram.py` | Hologram detection | Live |
| `template_match.py` | Cambodia ID template matching | Live |
| `llm_analyzer.py` | Claude API document reasoning | Live (enable in .env) |
| `anomaly_detect.py` | Isolation Forest anomaly detection | Live — trained 500 samples |
| `fraud_network.py` | Graph-based fraud ring detection | Live |
| `duplicate_detect.py` | Duplicate identity detection | Live |
| `alerts.py` | Email alert system | Live (enable in .env) |
| `report_gen.py` | PDF compliance report generator | Live |
| `export.py` | Excel/CSV export | Live |
| `auth.py` | KYC portal JWT authentication | Live |
| `api_keys.py` | API key management | Live |
| `portal.py` | KYC staff portal | Live |
| `dashboard.py` | Real-time fraud intelligence dashboard v2 | Live |
| `loan_portal.py` | Loan officer portal | Live |
| `loan_db.py` | Loan portal database models | Live |
| `loan_integration.py` | Loan integration API | Live |
| `applicant_portal.py` | Applicant self-service portal | Live |
| `webhook_receiver.py` | Webhook event receiver | Live |
| `sms_notifications.py` | Twilio SMS notifications | Live (enable in .env) |
| `train_targeted.py` | Training pipeline for large datasets | Live |
| `train_pipeline.py` | Full training pipeline with review | Live |

---

## 24. Feature Status (Final — April 2026)

| Feature | Status | Notes |
|---------|--------|-------|
| PDF screening with banking intelligence | Live | 9 checks |
| Image screening | Live | |
| ID card screening async + webhook | Live | |
| Cambodia ID templates (old + new + passport) | Live | |
| Khmer OCR | Live | |
| Face match + liveness (ArcFace) | Live | |
| MRZ checksum validation (TD1 + TD3) | Live | |
| Benford's Law analysis | Live | |
| Balance consistency check | Live | |
| Structuring detection | Live | |
| Template fingerprinting | Live | |
| Salary/payslip validation | Live | |
| ML classifier (MobileNetV2) | Live | Retrain with tampered samples |
| Anomaly detection (Isolation Forest) | Live | Trained on 500 genuine docs |
| Fraud network detection | Live | |
| Duplicate ID detection | Live | |
| Velocity checks | Live | |
| KYC staff portal | Live | |
| Compliance PDF reports | Live | |
| Excel/CSV export | Live | |
| Email alerts | Live | Enable ALERTS_ENABLED=true |
| Webhook integration | Live | |
| Batch ZIP processing | Live | |
| Expiry tracker | Live | |
| Real-time fraud dashboard v2 | Live | Auto-refreshes 30s |
| Loan Integration API (/api/v1/) | Live | |
| Loan Officer Portal (/loan/) | Live | |
| Applicant Self-Service Portal (/apply/) | Live | |
| Bilingual UI (Khmer + English) | Live | |
| Phone OTP login | Live | |
| Background async KYC submission | Live | No more 504 timeouts |
| Applicant→Loan portal sync | Live | Auto-mirrors to loan officers |
| SMS notifications (Twilio) | Live | Upgrade Twilio for production |
| Document training pipeline | Live | 65k docs supported |
| LLM document reasoning | Built | Enable LLM_ANALYSIS_ENABLED=true |
| Fraud network graph visualisation | Planned | |
| Automated decision engine | Planned | |
| Cambodia government ID verification | Planned | |
| WhatsApp/Telegram bot | Planned | |
| ML retraining pipeline (auto) | Planned | |
| Credit bureau integration | Planned | |
| Core banking system integration | Planned | |

---

*Document updated: April 2026 | Version 4.0 | Confidential — Internal use only*
